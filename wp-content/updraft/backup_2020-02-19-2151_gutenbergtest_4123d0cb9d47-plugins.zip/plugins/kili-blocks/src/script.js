import "./blocks/layout2/script";
import "./blocks/team-member/script";
